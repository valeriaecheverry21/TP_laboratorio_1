#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "funciones.h"
#define TAM 20




int menu(char mensaje[],char error[]){
    int opcion,aux;
    printf("%s",mensaje);
    aux=scanf("%d",&opcion);
    fflush(stdin);
    while(aux==0 ||(opcion<1||opcion>5))
    {
        printf("%s",error);
        fflush(stdin);
        aux=scanf("%d",&opcion);
    }
    return opcion;
}

int obtenerEspacioLibre(EPersona registro[]){
    int i;
    int resultado;
    int flagEspacio=0;
    for(i=0; i<TAM; i++)
    {
        if(registro[i].estado==0)
        {
            resultado=i;
            flagEspacio=1;
            break;
        }
    }
    if(flagEspacio==0)
    {
        resultado=-1;
    }
    return resultado;
}

void agregarPersona(EPersona registro[]){
    int x=obtenerEspacioLibre(registro);
    char auxNombre[100]= {};
    if(x==-1)
    {
        printf("Se completo el espacio, necesita borrar una persona\n");
    }
    else
    {
        printf("Ingrese el nombre: ");
        fflush(stdin);
        gets(auxNombre);
        while(strlen(auxNombre)>49)
        {
            printf("Demasiado extenso, reingrese el nombre: ");
            fflush(stdin);
            gets(auxNombre);
        }
        strcpy(registro[x].nombre,auxNombre);
        printf("Ingresar edad: ");
        scanf("%d",&registro[x].edad);
        printf("Ingresar DNI: ");
        scanf("%d",&registro[x].dni);
        registro[x].estado=1;
    }

}

int buscarPorDni(EPersona registro[]){
    int i;
    int resultado;
    int flagDni=0;
    int dni;
    printf("Ingrese el dni a buscar: ");
    scanf("%d",&dni);
    for(i=0; i<TAM; i++)
    {
        if(dni==registro[i].dni && registro[i].estado==1)
        {
            resultado=i;
            flagDni=1;
            break;
        }
    }
    if(flagDni==0)
    {
        resultado=-1;
    }
    return resultado;
}

void mostrarOrdenado(EPersona registro[]){
    int i,j;
    EPersona aux= {};
    for(i=0; i<TAM-1; i++)
    {
        for(j=i+1; j<TAM; j++)
        {
            if(strcmp(registro[i].nombre,registro[j].nombre)>0)
            {
                aux=registro[i];
                registro[i]=registro[j];
                registro[j]=aux;
            }
        }
    }
    for(i=0; i<TAM; i++)
    {
        if(registro[i].estado==1)
        {
            printf("\nDNI: %d\tNOMBRE: %s\t EDAD: %d",registro[i].dni,registro[i].nombre,registro[i].edad);
        }
    }
    printf("\n");
}

int eliminarPersona(EPersona registro[]){
    int i=buscarPorDni(registro);
    char respuesta;
    if(i==-1 || registro[i].estado==0)
    {
        printf("El dni ingresado es erroneo\n");
    }
    else
    {
        printf("\nDNI: %d\tNOMBRE: %s\t EDAD: %d",registro[i].dni,registro[i].nombre,registro[i].edad);
        printf("\nDesea eliminarlo? s/n: ");
        fflush(stdin);
        scanf("%c",&respuesta);
        if(respuesta=='s')
        {
            registro[i].estado=0;
            printf("Persona eliminada de la lista\n");
        }
        else
        {
            printf("Accion cancelada\n");
        }
    }
}

void grafico(EPersona registro[],int hasta18 , int de19a35 ,int mayorde35 ,int mayor ){
    int i,flag;
    for(i=0; i<TAM; i++)
    {
        flag=0;
        if(registro[i].estado==1)
        {
            if(registro[i].edad<=18)
            {
                hasta18++;
            }
            else
            {
                if(registro[i].edad>35)
                {
                    mayorde35++;
                }
                else
                {
                    de19a35++;
                }
            }
        }
    }
    if(hasta18 >= de19a35 && hasta18 >= mayorde35)
    {
        mayor = hasta18;
    }
    else
    {
        if(de19a35 >= hasta18 && de19a35 >= mayorde35)
        {
            mayor = de19a35;
        }
        else
        {
            mayor = mayorde35;
        }
    }
    for(i=mayor; i>0; i--)
    {
        if(i<10)
        {
            printf("%02d|",i);
        }

        if(i<= hasta18)
        {
            printf("*");
        }
        if(i<= de19a35)
        {
            flag=1;
            printf("\t*");
        }
        if(i<= mayorde35)
        {
            if(flag==0)
            {
                printf("\t\t*");
            }
            if(flag==1)
            {
                printf("\t*");
            }
        }
        printf("\n");
    }
    printf("--+-----------------");
    printf("\n  |<18\t19-35\t>35");
}
