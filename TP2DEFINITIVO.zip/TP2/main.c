#include <stdio.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "funciones.h"
#define TAM 20

int main()
{
    char seguir='s';
    int opcion=0;
    int i,j;
    int hasta18, de19a35, mayor35, mayor;
    int flag=0;
    EPersona registro[TAM],auxStruct;
     for(i=0;i<TAM;i++)    {
        strcpy(registro[i].nombre," ");
        registro[i].edad=0;
        registro[i].estado=0;
        registro[i].dni=0;
    }


    obtenerEspacioLibre(registro);

    while(seguir=='s')
    {
        system("cls");
        opcion = menu("1- AGREGAR PERSONA\n2- BORRAR PERSONA\n3- LISTADO DE NOMBRES\n4- GRAFICO DE EDADES\n\n5- Salir\n","Error ingrese nuevamente una opcion entre 1 y 5: ");

        switch(opcion)
        {
            case 1:
                agregarPersona(registro);
                system("pause");
                break;
            case 2:
               eliminarPersona(registro);
               system("pause");
                break;
           case 3:
                mostrarOrdenado(registro);
                system("pause");
                break;
            case 4:
                hasta18=0;
                de19a35=0;
                mayor35=0;
                grafico(registro, hasta18, de19a35, mayor35, mayor);
                system("pause");
                break;
            case 5:
                seguir = 'n';
                break;
        }
    }
    return 0;
}
