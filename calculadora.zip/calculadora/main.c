#include <stdio.h>
#include <stdlib.h>
#include "funciones.h"



int main()
{
    char seguir = 's';
    int opcion;
    float numeroA=0;
    float numeroB=0;
    int flagn1, flagn2;
    float resultado;



    while(seguir == 's')
    {
        system("cls");
        printf(" -------------CALCULADORA-------------\n");
        printf("1-INGRESE EL PRIMER NUMERO (A=%.2f)\n" ,numeroA);
        printf("2-INGRESE EL SEGUNDO NUMERO (B=%.2f)\n", numeroB);
        printf("3-CALCULAR SUMA (A+B) \n");
        printf("4-CALCULAR RESTA (A-B)\n");
        printf("5-CALCULAR DIVISION (A/B)\n");
        printf("6-CALCULAR MULTIPLICACION (A*B)\n");
        printf("7-CALCULAR FACTORIAL (A!)\n");
        printf("8-CALCULAR TODAS LAS OPERACIONES\n");
        printf("9- Salir\n");

        scanf("%d",&opcion);

        switch(opcion)
        {
            case 1:
                 printf("INGRESE PRIMER NUMERO :\n", numeroA);
                 scanf("%f",&numeroA);
                 flagn1 = 1;
                 break;

            case 2:
                 printf("INGRESE SEGUNDO NUMERO :\n", numeroB);
                 scanf("%f",&numeroB);
                 flagn2=1;
                 break;

            case 3:
                if(flagn1==0 || flagn2==0){
                    printf("ERROR DEBE INGRESAR UN NUMERO!");
                    break;
                }

                    resultado=sumar(numeroA, numeroB);
                    printf("lA SUMA ES : %.2f\n", resultado);
                    system("pause");
                    break;
            case 4:
                if(flagn1==0 || flagn2==0){
                    printf("ERROR DEBE INGRESAR UN NUMERO!");
                    break;
                }
                resultado=restar(numeroA, numeroB);
                printf("lA RESTA ES: %.2f\n", resultado);
                system("pause");
                break;
            case 5:
                if(flagn1==0 || flagn2==0){
                    printf("ERROR DEBE INGRESAR UN NUMERO!");
                    break;
                }
                if(flagn2==0){
                    printf("ERROR NO SE PUEDE DIVIDIR POR 0");
                    break;
                }


                resultado=division(numeroA, numeroB);
                printf("lA DIVISION ES: %.2f\n", resultado);
                system("pause");
                break;
            case 6:
                if(flagn1==0 || flagn2==0){
                    printf("ERROR DEBE INGRESAR UN NUMERO!!");
                    break;
                }
                resultado=multiplicacion(numeroA, numeroB);
                printf("lA MULTIPLICACION ES: %.2f\n", resultado);
                system("pause");
                break;
            case 7:
                if(flagn1==0 || flagn2==0){
                    printf("ERROR DEBE INGRESAR UN NUMERO!!");
                    break;
                }
                if(numeroA == 0 || numeroA!= (int) numeroA){
                    printf("ERROR");
                    break;
                }
                resultado=factorial(numeroA);
                printf("EL FACTORIAL ES: %.2f\n", resultado);
                system("pause");
                break;
            case 8:
                 if(flagn1==0 || flagn2==0){
                    printf("ERROR DEBE INGRESAR UN NUMERO!!");
                    break;
                }
                resultado=sumar(numeroA, numeroB);
                printf("LA SUMA ES : %.2f\n", resultado);

                resultado=restar(numeroA, numeroB);
                printf("LA RESTA ES: %.2f\n", resultado);
                 if(flagn2==0){
                    printf("ERROR, NO SE PUEDE DIVIDIR POR 0");

                }
                if(flagn2!= 0){
                resultado=division(numeroA, numeroB);
                printf("LA DIVISION ES: %.2f\n", resultado);

                }


                resultado=multiplicacion(numeroA, numeroB);
                printf("LA MULTIPLICACION ES %.2f\n", resultado);


                if(numeroA!=0 || numeroA== (long long int) numeroA){
                 resultado=factorial(numeroA);
                 printf("EL FACTORIAL ES: %f\n", resultado);
                 system("pause");
                }
                break;
            case 9:
                seguir = 'n';
                break;
        }


}

    return 0;
}
