

float sumar(float n1, float n2){
 float resultado;
 resultado=n1+n2;
return resultado;
}


float restar(float n1, float n2){
 float resultado;
 resultado=n1-n2;
return resultado;
}


float division(float n1, float n2){
 float resultado;
 resultado=n1/n2;
return resultado;
}


float multiplicacion(float n1, float n2){
float resultado;
resultado=n1*n2;
return resultado;
}


float factorial(long long int n1){
    long long int factorial = 1, contador;

    for(contador = 1; contador <= n1; contador++)
    {
        factorial = factorial * contador;
    }
return factorial;
}
